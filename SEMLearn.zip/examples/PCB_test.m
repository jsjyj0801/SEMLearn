data = 'alarm';       % generate data from this alarm network
nSamples = 1000;    % the number of samples
nEvals = 2500;       % the maximum number of family evaluations 
discrete = 0;         % set to 0 for continuous data
interv = 0;           % set to 0 for observational data
rand('state',0);        % generate data randomly
randn('state',0);
[X,clamped,G,nodeNames] = sampleNetwork1(data,nSamples,discrete,interv,1); %generate data
penalty = log(nSamples)/2;  % weight of free parameter term
[nSamples,numOfVar]=size(X) % get the size of the data
DAG_PCB=zeros(numOfVar); % used to record the final network
tic
k=0.1           % set threshold 0.1
[CC]=PCB(X,k)   % run the PCB algorithm to get the network skeleton 

DAG_PCB= DAGsearch(X,nEvals,0,penalty,discrete,clamped,CC);
                          % get the final network structure
t_run=toc                    % record the run time
numberL1MB=sum(DAG_PCB(:)~=G(:))    
% record the structural errors by comparing the original network G and the learned network 
% DAG_PCB

