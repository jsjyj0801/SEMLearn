%2.������˹�ֲ������ݣ�TC�㷨����ģ�Ȩֵ����[0.2,1]���Ŷ����ϱ�׼��̬�ֲ�, 
%û�и�ĸ�ڵ�Ĳ�����ֵ0��ƫ��1�ı�׼��̬���ݣ��и�ĸ�Ľڵ���������丸�ڵ�����Ժ������Ŷ��Ǳ�׼��̬�ֲ������ݣ�
%2.Generate datasets which belong to a multivariate Gaussian distribution, the method is proposed by TC, 
% and coefficients randomly distributed uniformly between 0.2 and 1, the disturbance terms are drawn from standard Gaussian distribution. The parentless variables are 
%sampled from the standard Gaussian distribution with zero mean and unit standard deviation; the other variables are defined as linear combinations of 
%their parents


data = 'alarm';
nSamples = 1000;
nEvals = 2500;
discrete = 0; % Set to 1 for binary data
interv = 0; % Set to 0 for observational data
rand('state',0);
randn('state',0);
[X,clamped,G,nodeNames] = sampleNetwork2(data,nSamples,discrete,interv,1);
 t_run=zeros(1,6);

[nSamples,numOfVar]=size(X)
penalty = log(nSamples)/2;


DAG_PCB=zeros(numOfVar);
DAG_L1MB=zeros(numOfVar);
DAG_TC=zeros(numOfVar);
DAG_TP=zeros(numOfVar);
DAG_EQU_BEG_half=zeros(numOfVar);
DAG_BSEM=zeros(numOfVar);

DAG_PCS=zeros(numOfVar);


tic
k=0.1
[CC]=PCB(X,k)

DAG_PCB= DAGsearch(X,nEvals,0,penalty,discrete,clamped,CC);
t_run(1,1)=toc

numberPCB=sum(DAG_PCB(:)~=G(:))

tic
[L1MB_AND,L1MB_OR] = L1MB(X,penalty,discrete,clamped,nodeNames);
DAG_L1MB = DAGsearch(X,nEvals,0,penalty,discrete,clamped,L1MB_OR);
t_run(1,2)=toc

numberL1MB=sum(DAG_L1MB(:)~=G(:))


k=0.005;

tic
[DAG_TC]=TC(X,k) 
t_run(1,3)=toc
numberTC=sum(DAG_TC(:)~=G(:))

k=0.005
tic
 DAG_EQU_BEG_half=BSEM(X,k)
 DAG_BSEM= DAGsearch(X,nEvals,0,penalty,discrete,clamped,DAG_EQU_BEG_half);
t_run(1,4)=toc

numberBSEM=sum(DAG_BSEM(:)~=G(:))

tic
[CC]=PCS(X,k)
DAG_PCS= DAGsearch(X,nEvals,0,penalty,discrete,clamped,CC);
t_run(1,5)=toc

numberPCS=sum(DAG_PCS(:)~=G(:))

tic
[DAG_TP]=Two_phase(X,k)
t_run(1,6)=toc

numberTwo_phase=sum(DAG_TP(:)~=G(:))




err=zeros(1,6);
err(1,1)=numberPCB;
err(1,2)=numberL1MB;
err(1,3)=numberTC;
err(1,4)=numberBSEM;
err(1,5)=numberPCS;
err(1,6)=numberTwo_phase;

