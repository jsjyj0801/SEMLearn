data = 'alarm';       % generate data from this alarm network
nSamples = 1000;    % the number of samples
nEvals = 2500;       % the maximum number of family evaluations 
discrete = 0;         % set to 0 for continuous data
interv = 0;           % set to 0 for observational data
rand('state',0);        % generate data randomly
randn('state',0);
[X,clamped,G,nodeNames] = sampleNetwork1(data,nSamples,discrete,interv,1); %generate data
penalty = log(nSamples)/2;  % weight of free parameter term
[nSamples,numOfVar]=size(X) % get the size of the data
DAG_L1MB=zeros(numOfVar); % used to record the final network
tic
[L1MB_AND,L1MB_OR] = L1MB(X,penalty,discrete,clamped,nodeNames);
% run the L1MB algorithm to get the network skeleton 
DAG_L1MB = DAGsearch(X,nEvals,0,penalty,discrete,clamped,L1MB_OR);
                           % get the final network structure
t_run=toc                    % record the run time
numberL1MB=sum(DAG_L1MB(:)~=G(:))    
% record the structural errors by comparing the original network G and the learned network 
% DAG_L1MB

