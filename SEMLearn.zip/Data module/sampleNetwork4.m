function [X,clamped,dag,nodeNames,mynet] = sampleNetwork(name,nSamples,discrete,probInt,verbose)
%
% name:
%   'chain'
%   'alarm'
%   'insurance'
%   etc.
%
% nSamples:
%   number of samples to generate from network
%
% discrete:
%   0: sample from Gaussian Belief Net
%   1: sample from Sigmoid Belief Net
%
% probInt:
%   for each sample, intervene
%       on a randomly chosen node with this probability

if nargin < 3
    discrete = 0;
end
if nargin < 4
    probInt = 0;
end
if nargin < 5
    verbose = 1;
end

if verbose
if probInt == 0
    fprintf('Generating Observational Data\n');
else
    fprintf('Generating Data w/ Interventions\n');
end
end

if verbose
if discrete == 0
    fprintf('Generating from Gaussian Belief Net\n');
else
    fprintf('Generating from Sigmoid Belief Net\n');
end
end

% Get DAG
dagFunc = str2func(strcat('getDAG',name));
[dag,nodeNames] = dagFunc();
n = length(dag);

% Make CPDs
for i = 1:n
    if discrete == 0
        mynet.mu{i} = 0;
        mynet.sigma{i} = 1;
        mynet.weights{i} = dag(:,i).*(sign(rand(n,1)-.5)+randn(n,1)/4);
        %���� +/- 1+N��0��1��/4��Χ�����������PCB�㷨��1��2 ʹ�ø�Ȩֵ

               
    else
        mynet.bias{i} = 0;
        mynet.weights{i} = dag(:,i).*(sign(rand(n,1)-.5)+randn(n,1)/4);
    end
end

% Generate Samples
clamped = zeros(nSamples,n);
X = zeros(nSamples,n);
interventional = rand(nSamples,1) < probInt;
clampedNode = ceil(rand(nSamples,1)*n);
for i = 1:nSamples

    % Perform Random PerfectIntervention
    if interventional(i)
        clamped(i,clampedNode(i)) = 1;
    end

end

for j = 1:n
    % Sample (assumes 'dag' is upper triangular)
    if discrete == 0
         a=-3
         b=3 
        X(:,j)=mynet.mu{j}+X*mynet.weights{j}+a + (b-a).*rand(nSamples,1) 
        
        %4. �����Ǹ�˹�ֲ������ݣ�Ȩֵ������̬�ֲ���+/- 1+N��0��1��/4���Ŷ�����[-3,3]��Χ�ľ��ȷֲ���rand�����������ȷֲ�����
        %û�и�ĸ�ڵ�Ĳ���[-3,3]��Χ�ľ��ȷֲ����ݣ��и�ĸ�Ľڵ���������丸�ڵ�����Ժ���
        %generate datasets which do not belong a non-multivariate Gaussian distribution,
        % and coefficients randomly sampled from ��1 + N (0, 1)/4, the disturbance terms are drawn from the uniform distribution between -3 and 3. The parentless variables are 
          %sampled from the uniform distribution between -3 and 3; the other variables are defined as linear combinations of 
           % their parents




        for i = 1:nSamples
            if clamped(i,j)
                X(i,j) = n*randn;
            end
        end
    else
        X(:,j) = sign(rand(nSamples,1) - 1./(1+exp(-X*mynet.weights{j}-mynet.bias{j})));
        for i = 1:nSamples
            if clamped(i,j)
                X(i,j) = sign(rand-.5);
            end
        end
    end
end


