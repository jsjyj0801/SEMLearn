%For no-Gaussian, the residual of squares(RSS) is used to calculate the score of family. The computation method of RSS has same formula 
%as the negative log-likelihood of Gaussion data except the constant term. So for non-Gaussian data, we still use this function.

function [nll] = GLoss(XX,Xy,yy,w)
    nll = (1/2)*(w'*XX*w - 2*w'*Xy + yy);
end