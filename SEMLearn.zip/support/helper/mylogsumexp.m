function lse = mylogsumexp(b)
% does logsumexp across columns
B = max(b,[],2);
if issparse(b)
    lse = log(sum(exp(b-repmat(B,[1 size(b,2)])),2))+B;
    ls=log(sum(exp(b),2))+b(:,2);
    ls1=log(sum(exp(b),2));
else
    lse = log(sum(exp(b-repmatC(B,[1 size(b,2)])),2))+B;
    ls=log(sum(exp(b),2))+b(:,2);
    ls1=log(sum(exp(b),2));
end
end