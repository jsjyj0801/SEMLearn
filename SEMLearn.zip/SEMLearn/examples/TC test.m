data = 'alarm';       % generate data from this alarm network
nSamples = 1000;    % the number of samples
nEvals = 2500;       % the maximum number of family evaluations 
discrete = 0;         % set to 0 for continuous data
interv = 0;           % set to 0 for observational data
rand('state',0);        % generate data randomly
randn('state',0);
[X,clamped,G,nodeNames] = sampleNetwork1(data,nSamples,discrete,interv,1); %generate data
penalty = log(nSamples)/2;  % weight of free parameter term
[nSamples,numOfVar]=size(X) % get the size of the data
DAG_TC=zeros(numOfVar); % used to record the final network
k=0.005;                 % set threshold 0.005 
tic
[DAG_TC]=TC(X,k)                      % run the TC algorithm to get the final network structure
t_run=toc                    % record the run time
numberTC=sum(DAG_TC(:)~=G(:))    
% record the structural errors by comparing the original network G and the learned network 
% DAG_TC

